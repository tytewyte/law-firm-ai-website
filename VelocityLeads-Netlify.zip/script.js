function qs(selector, root = document) {
  return root.querySelector(selector);
}

function qsa(selector, root = document) {
  return Array.from(root.querySelectorAll(selector));
}

function setYear() {
  const year = qs('#year');
  if (!year) return;
  year.textContent = String(new Date().getFullYear());
}

function setupMobileNav() {
  const toggle = qs('.nav-toggle');
  const menu = qs('#nav-menu');
  if (!toggle || !menu) return;

  function closeMenu() {
    menu.dataset.open = 'false';
    toggle.setAttribute('aria-expanded', 'false');
  }

  function openMenu() {
    menu.dataset.open = 'true';
    toggle.setAttribute('aria-expanded', 'true');
  }

  toggle.addEventListener('click', () => {
    const open = menu.dataset.open === 'true';
    if (open) closeMenu();
    else openMenu();
  });

  qsa('a[href^="#"]', menu).forEach((link) => {
    link.addEventListener('click', () => {
      closeMenu();
    });
  });

  document.addEventListener('click', (e) => {
    if (!menu.contains(e.target) && !toggle.contains(e.target)) {
      closeMenu();
    }
  });

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeMenu();
    }
  });
}

function setupAccordion() {
  const root = qs('[data-accordion]');
  if (!root) return;

  const items = qsa('.faq-item', root);

  items.forEach((item) => {
    const button = qs('.faq-q', item);
    const answer = qs('.faq-a', item);
    if (!button || !answer) return;

    button.addEventListener('click', () => {
      const isOpen = item.dataset.open === 'true';

      items.forEach((other) => {
        if (other === item) return;
        const otherButton = qs('.faq-q', other);
        const otherAnswer = qs('.faq-a', other);
        if (!otherButton || !otherAnswer) return;

        other.dataset.open = 'false';
        otherButton.setAttribute('aria-expanded', 'false');
        otherAnswer.hidden = true;
      });

      item.dataset.open = String(!isOpen);
      button.setAttribute('aria-expanded', String(!isOpen));
      answer.hidden = isOpen;
    });
  });
}

function showToast(message) {
  const toast = qs('#toast');
  if (!toast) return;
  const text = qs('.toast-text', toast);
  if (text) text.textContent = message;

  toast.hidden = false;
  window.clearTimeout(showToast._timer);
  showToast._timer = window.setTimeout(() => {
    toast.hidden = true;
  }, 2400);
}

async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

function setupContactForm() {
  return;
}

function setupCtaTracking() {
  qsa('[data-cta]').forEach((el) => {
    el.addEventListener('click', () => {
      const name = el.getAttribute('data-cta');
      if (!name) return;
      try {
        sessionStorage.setItem('lastCta', name);
      } catch {
        // ignore
      }
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  setYear();
  setupMobileNav();
  setupAccordion();
  setupContactForm();
  setupCtaTracking();
});
